import sys
import time
import joblib
import pandas as pd
import numpy as np
from pathlib import Path

from blocking import (
    generate_blocking_keys,
    extract_name_features,
    extract_address_features,
)
from matching import extract_pair_features
def make_blocking_keys(name, address, country):
    if pd.isna(name):
        name = ""

    if pd.isna(address):
        address = ""

    if pd.isna(country):
        country = ""

    name = str(name)
    address = str(address)
    country = str(country)

    name_tokens, name_concat, prefixes = extract_name_features(name)
    address_numbers, address_words = extract_address_features(address)

    return generate_blocking_keys(
        country,
        name_tokens,
        name_concat,
        prefixes,
        address_numbers,
        address_words,
    )
BASE = Path("student_resource/dataset")
MODEL_PATH = Path("output/matching_model.pkl")

MAX_KEY_FREQ = 5000


def load_data(split):
    if split == "val":
        s1 = pd.read_csv(
            BASE / "val" / "val_source1.tsv",
            sep="\t"
        )

        s2 = pd.read_csv(
            BASE / "train" / "train_source2.tsv",
            sep="\t"
        )

        s3 = pd.read_csv(
            BASE / "train" / "train_source3.tsv",
            sep="\t"
        )

    else:
        s1 = pd.read_csv(
            BASE / split / f"{split}_source1.tsv",
            sep="\t"
        )

        s2 = pd.read_csv(
            BASE / split / f"{split}_source2.tsv",
            sep="\t"
        )

        s3 = pd.read_csv(
            BASE / split / f"{split}_source3.tsv",
            sep="\t"
        )

    s2["source"] = "source2"
    s3["source"] = "source3"

    candidates = pd.concat([s2, s3], ignore_index=True)

    return s1, candidates


def build_index(candidates):
    print("Building blocking index...")

    index = {}

    for i, row in candidates.iterrows():
        keys = make_blocking_keys(
    row["business_name"],
    row["business_address"],
    row["country"],
)
        for key in keys:
            if key not in index:
                index[key] = []

            if len(index[key]) <= MAX_KEY_FREQ:
                index[key].append(i)

        if i % 1_000_000 == 0:
            print(f"Indexed {i:,} records...")

    index = {
        k: v for k, v in index.items()
        if len(v) <= MAX_KEY_FREQ
    }

    print(f"Index keys: {len(index):,}")

    return index


def get_candidates(row, index):
    keys = make_blocking_keys(
    row["business_name"],
    row["business_address"],
    row["country"],
)

    ids = set()

    for key in keys:
        ids.update(index.get(key, []))

    return ids


def score_candidates(s1_row, candidate_ids, candidates, model):
    results = []

    s1_record = {
        "business_name": "" if pd.isna(s1_row["business_name"]) else str(s1_row["business_name"]),
        "business_address": "" if pd.isna(s1_row["business_address"]) else str(s1_row["business_address"]),
        "country": "" if pd.isna(s1_row["country"]) else str(s1_row["country"]),
    }

    feature_rows = []
    valid_ids = []

    for cid in candidate_ids:
        row = candidates.iloc[cid]

        candidate_record = {
            "business_name": "" if pd.isna(row["business_name"]) else str(row["business_name"]),
            "business_address": "" if pd.isna(row["business_address"]) else str(row["business_address"]),
            "country": "" if pd.isna(row["country"]) else str(row["country"]),
        }

        feature_rows.append(
            extract_pair_features(
                s1_record,
                candidate_record
            )
        )

        valid_ids.append(cid)

    if not feature_rows:
        return []

    # Batch prediction — much faster than predicting one pair at a time
    probabilities = model.predict_proba(
        np.asarray(feature_rows, dtype=np.float32)
    )[:, 1]

    return list(zip(valid_ids, probabilities))


def run_validation():
    print("\n=== VALIDATION ===")

    s1, candidates = load_data("val")

    gt = pd.read_csv(
        BASE / "val" / "val_ground_truth.tsv",
        sep="\t"
    )

    model = joblib.load(MODEL_PATH)

    index = build_index(candidates)

    thresholds = [0.50, 0.60, 0.70, 0.80, 0.90, 0.95]

    predictions = {}

    start = time.time()

    for n, (_, row) in enumerate(s1.iterrows(), 1):

        candidate_ids = get_candidates(row, index)

        scored = score_candidates(
            row,
            candidate_ids,
            candidates,
            model
        )

        predictions[row["entity_id"]] = scored

        if n % 1000 == 0:
            elapsed = time.time() - start
            print(
                f"Processed {n:,}/{len(s1):,} "
                f"({elapsed:.1f}s)"
            )

    print("\nScoring complete.")

    gt_map = {}

    for _, row in gt.iterrows():
        gt_ids = row["matched_entity_ids"]

        if pd.isna(gt_ids) or str(gt_ids).strip() == "":
            gt_map[row["source1_entity_id"]] = set()
        else:
            gt_map[row["source1_entity_id"]] = set(
                str(gt_ids).split(",")
            )

    print("\nThreshold results:")

    best_threshold = None
    best_f05 = -1

    for threshold in thresholds:

        total_f05 = 0
        total_precision = 0
        total_recall = 0

        count = 0

        for s1_id, scored in predictions.items():

            predicted_ids = {
                str(candidates.iloc[cid]["entity_id"])
                for cid, prob in scored
                if prob >= threshold
            }

            truth = gt_map.get(s1_id, set())

            if len(truth) == 0:
                f05 = 1.0 if len(predicted_ids) == 0 else 0.0
                precision = 1.0 if len(predicted_ids) == 0 else 0.0
                recall = 1.0 if len(predicted_ids) == 0 else 0.0
            else:
                tp = len(truth & predicted_ids)

                precision = (
                    tp / len(predicted_ids)
                    if predicted_ids else 0.0
                )

                recall = tp / len(truth)

                f05 = (
                    (1.25 * precision * recall) /
                    (0.25 * precision + recall)
                    if precision + recall > 0
                    else 0.0
                )

            total_f05 += f05
            total_precision += precision
            total_recall += recall
            count += 1

        avg_f05 = total_f05 / count
        avg_precision = total_precision / count
        avg_recall = total_recall / count

        print(
            f"Threshold {threshold:.2f} | "
            f"F0.5={avg_f05:.5f} | "
            f"Precision={avg_precision:.5f} | "
            f"Recall={avg_recall:.5f}"
        )

        if avg_f05 > best_f05:
            best_f05 = avg_f05
            best_threshold = threshold

    print("\n==============================")
    print(f"BEST THRESHOLD: {best_threshold}")
    print(f"BEST F0.5:     {best_f05:.5f}")
    print("==============================")


def run_test():
    print("\n=== TEST INFERENCE ===")

    s1, candidates = load_data("test")

    model = joblib.load(MODEL_PATH)

    index = build_index(candidates)

    # Conservative threshold because the challenge uses F0.5
    # and precision is more important than recall.
    threshold = 0.80

    output_rows = []

    start = time.time()

    for n, (_, row) in enumerate(s1.iterrows(), 1):

        candidate_ids = get_candidates(row, index)

        scored = score_candidates(
            row,
            candidate_ids,
            candidates,
            model
        )

        matched_ids = []

        for cid, probability in scored:
            if probability >= threshold:
                matched_ids.append(
                    str(candidates.iloc[cid]["entity_id"])
                )

        # Remove duplicates
        matched_ids = list(dict.fromkeys(matched_ids))

        output_rows.append({
            "source1_entity_id": str(row["entity_id"]),
            "matched_entity_ids": ",".join(matched_ids)
        })

        if n % 1000 == 0:
            elapsed = time.time() - start
            print(
                f"Processed {n:,}/{len(s1):,} "
                f"({elapsed:.1f}s)"
            )

    output_path = Path("output/matching_results.tsv")
    output_path.parent.mkdir(exist_ok=True)

    result = pd.DataFrame(
        output_rows,
        columns=[
            "source1_entity_id",
            "matched_entity_ids"
        ]
    )

    result.to_csv(
        output_path,
        sep="\t",
        index=False
    )

    print("\n==============================")
    print("Matching results generated!")
    print(f"File: {output_path}")
    print(f"Rows: {len(result):,}")
    print("==============================")


def main():
    if len(sys.argv) != 2:
        print("Usage:")
        print("  python3 src/inference.py validation")
        print("  python3 src/inference.py test")
        sys.exit(1)

    mode = sys.argv[1]

    if mode == "validation":
        run_validation()
    elif mode == "test":
        run_test()
    else:
        print("Unknown mode:", mode)


if __name__ == "__main__":
    main()

if __name__ == "__main__":
    main()